package tendemo;

import java.io.IOException;

public class Ten {
	 
	public static void main(String[] args) {
        Subclass obj = new Subclass();
        try {
            obj.doSomething();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
