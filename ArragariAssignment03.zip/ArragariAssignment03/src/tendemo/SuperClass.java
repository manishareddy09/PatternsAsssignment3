package tendemo;

import java.io.IOException;

public class SuperClass {
	
	void doSomething() throws IOException {
        // some code that can throw IOException
    }
}

class Subclass extends SuperClass {
    // this is a valid override
    void doSomething() throws IOException {
        // some code that can throw IOException
    }
    
    // this is not a valid override, as it adds an unchecked exception
    void doSomethingElse() throws RuntimeException {
        // some code that throws a RuntimeException
    }
    
    // this is also not a valid override, as it adds a checked exception
    void doSomethingDifferent() throws Exception {
        // some code that throws an Exception
    }

}
