package sevendemo;

public class Employee extends Person{
	
	private final String employeeId;

    // Here we get compile-time error, if we add constructor as the Person constructor is
	//marked as final
    public Employee(String name, int age, String employeeId) {
        super(name, age);
        this.employeeId = employeeId;
    }

    public String getEmployeeId() {
        return employeeId;
    }

}
