package sevendemo;

public class PersonDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 Employee employee = new Employee("Jung", 25, "Kook");
	        System.out.println("Name: " + employee.getName());
	        System.out.println("Age: " + employee.getAge());
	        System.out.println("Employee ID: " + employee.getEmployeeId());
	    }
	}


