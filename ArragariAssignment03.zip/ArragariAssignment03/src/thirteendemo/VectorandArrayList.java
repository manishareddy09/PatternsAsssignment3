package thirteendemo;

import java.util.ArrayList;
import java.util.Vector;

public class VectorandArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        // Creating a vector
        Vector<Integer> vector = new Vector<Integer>();
        
        // Adding elements to the vector
        vector.add(1);
        vector.add(2);
        vector.add(3);
        
        // Creating an array list
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        
        // Adding elements to the array list
        arrayList.add(1);
        arrayList.add(2);
        arrayList.add(3);        
        // Accessing an element
        System.out.println("Element at index 1 in vector: " + vector.get(1));
        System.out.println("Element at index 1 in array list: " + arrayList.get(1));        
        // Adding an element
        vector.add(4);
        arrayList.add(4);        
        // Size of the collections
        System.out.println("Size of the vector: " + vector.size());
        System.out.println("Size of the array list: " + arrayList.size());
    }
	

}
