package twentysixdemo;

public class MySingleton {
	private static MySingleton instance;

    private MySingleton() {
        // Private constructor to prevent instantiation from outside
    }

    public static MySingleton getInstance() {
        if (instance == null) {
            instance = new MySingleton();
        }
        return instance;
    }

    public void showMessage() {
        System.out.println("Hello, I am a pure singleton!");
    }

}
