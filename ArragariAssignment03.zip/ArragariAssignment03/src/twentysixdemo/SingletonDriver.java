package twentysixdemo;

public class SingletonDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MySingleton singleton1 = MySingleton.getInstance();
        MySingleton singleton2 = MySingleton.getInstance();

        System.out.println("Is singleton1 the same object as singleton2? " + (singleton1 == singleton2));

        singleton1.showMessage();
	}

}
