package onedemo;

public class MyGenericClass<T> {

	    private T data;

	    public MyGenericClass(T data) {
	        this.data = data;
	    }
	    public T getData() {
	        return data;
	    }
	    public void setData(T data) {
	        this.data = data;
	    }
	    public void printOutput() {
	        System.out.println("Result: " + data.toString());
	    }
	    public static void main(String[] args) {
	    	
	    	MyGenericClass<Integer> myInt = new MyGenericClass<Integer>(20);
	    	myInt.printOutput();

	    	MyGenericClass<String> myString = new MyGenericClass<String>("Hi! How are you?");
	    	myString.printOutput();
	    	
	    	}
	}


