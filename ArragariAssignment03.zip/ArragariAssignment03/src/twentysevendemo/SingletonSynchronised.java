package twentysevendemo;

public class SingletonSynchronised {
private static SingletonSynchronised instance;
    
    private SingletonSynchronised() {
        // Private constructor to prevent instantiation
    }
    
    public static synchronized SingletonSynchronised getInstance() {
        if (instance == null) {
            instance = new SingletonSynchronised();
        }
        return instance;
    }
}
