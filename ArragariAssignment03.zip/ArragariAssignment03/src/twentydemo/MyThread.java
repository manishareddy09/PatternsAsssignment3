package twentydemo;

public class MyThread implements Runnable{
	
	public synchronized void run() {
        System.out.println("Thread is running in state: " + Thread.currentThread().getState());

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Thread is running in state: " + Thread.currentThread().getState());
	}

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		 Thread t1 = new Thread(new MyThread()); // new state
	        System.out.println("Thread is in new state: " + t1.getState());

	        t1.start(); // runnable state
	        System.out.println("Thread is in runnable state: " + t1.getState());

	        Thread.sleep(200); // sleeping for a short duration to let the thread execute

	        System.out.println("Thread is in " + t1.getState() + " state now");

	        synchronized (t1) {
	            t1.wait(); // waiting state
	            System.out.println("Thread is in waiting state: " + t1.getState());
	        }

	        synchronized (t1) {
	            t1.notify(); // timed waiting state
	            System.out.println("Thread is in timed waiting state: " + t1.getState());
	        }

	        try {
	            t1.join(); // terminated state
	            System.out.println("Thread is in terminated state: " + t1.getState());
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
	}


