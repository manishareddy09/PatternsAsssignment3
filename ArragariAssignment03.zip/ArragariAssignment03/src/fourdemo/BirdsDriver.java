package fourdemo;

public class BirdsDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Birds.makeSound(); // Animal is making a sound
        Peacock.makeSound();
	}

}
