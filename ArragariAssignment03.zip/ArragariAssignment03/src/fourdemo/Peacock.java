package fourdemo;

public class Peacock {
	public static void makeSound() {
        System.out.println("Koo");
    }
	/* This will result in a compile-time error since privateMethod() cannot be accessed in the subclass
    private void privateMethod() {
        System.out.println("This is a private method in Peacock class");
    }
    */
}
