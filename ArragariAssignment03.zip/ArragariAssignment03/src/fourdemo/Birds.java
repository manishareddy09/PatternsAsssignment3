package fourdemo;

public class Birds {
	public static void makeSound() {
        System.out.println("Birds make sounds");
    }
	private void privateMethod() {
        System.out.println("This is a private method in Birds class");
    }
}
