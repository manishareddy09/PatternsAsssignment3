package fifteendemo;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class HashtableandHashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Create a Hashtable and add some elements
        Map<Integer, String> hashtable = new Hashtable<>();
        hashtable.put(1, "one");
        hashtable.put(2, "two");
        hashtable.put(3, "three");
        // Uncomment the following line to see the exception
        // hashtable.put(null, "null"); // throws NullPointerException

        // Create a HashMap and add some elements
        Map<Integer, String> hashmap = new HashMap<>();
        hashmap.put(1, "one");
        hashmap.put(2, "two");
        hashmap.put(3, "three");
        hashmap.put(null, "null");
        // Print the elements in the Hashtable
        System.out.println("Hashtable:");
        synchronized (hashtable) {
            for (Map.Entry<Integer, String> entry : hashtable.entrySet()) {
                System.out.println(entry.getKey() + " - " + entry.getValue());
            }
        }
        // Print the elements in the HashMap
        System.out.println("HashMap:");
        for (Map.Entry<Integer, String> entry : hashmap.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }
    
	}

}
