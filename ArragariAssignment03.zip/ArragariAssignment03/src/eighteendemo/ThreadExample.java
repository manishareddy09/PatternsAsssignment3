package eighteendemo;

public class ThreadExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// create a new instance of MyThread
        MyThread myThread = new MyThread();

        // start the thread
        Thread thread = new Thread(myThread);
        thread.start();

        // create a new instance of MyThread and start it again
        MyThread myThread2 = new MyThread();
        Thread thread2 = new Thread(myThread2);
        thread2.start();
	}

}
