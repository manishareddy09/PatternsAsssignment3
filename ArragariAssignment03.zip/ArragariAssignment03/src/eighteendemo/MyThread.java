package eighteendemo;

public class MyThread implements Runnable {
    public void run() {
        // thread logic goes here
    }
}
