package sixdemo;

public class StringandStringBuffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str1 = "Patterns";
        String str2 = "Frameworks";
        String str3 = str1 + " " + str2;

        StringBuffer stringBuffer1 = new StringBuffer("Patterns");
        StringBuffer stringBuffer2 = new StringBuffer("Frameworks");
        stringBuffer1.append(" ");
        stringBuffer1.append(stringBuffer2);
        String str4 = stringBuffer1.toString();

        System.out.println("String concatenation using String: " + str3);
        System.out.println("String concatenation using StringBuffer: " + str4);
	}

}
