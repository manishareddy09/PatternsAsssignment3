package seventeendemo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class IteratorExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  ArrayList<String> arrayList = new ArrayList<>();
	        arrayList.add("John");
	        arrayList.add("Mary");
	        arrayList.add("Bob");

	        // fail-fast iterator
	        System.out.println("Fail-fast iterator:");
	        Iterator<String> iterator = arrayList.iterator();
	        while (iterator.hasNext()) {
	            System.out.println(iterator.next());
	            // modifying the collection while iterating
	            arrayList.add("Alice");
	        }

	        // fail-safe iterator
	        System.out.println("\nFail-safe iterator:");
	        CopyOnWriteArrayList<String> copyOnWriteArrayList = new CopyOnWriteArrayList<>(arrayList);
	        Iterator<String> iterator1 = copyOnWriteArrayList.iterator();
	        while (iterator1.hasNext()) {
	            System.out.println(iterator1.next());
	            // modifying the collection while iterating
	            copyOnWriteArrayList.add("Alice");
	        }
	    }
	}


