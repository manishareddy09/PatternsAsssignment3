package threedemo;

public class AnimalDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal animal = new Animal();
        Animal dog = new Dog();

        Animal newbornAnimal = animal.givesBirth();
        Dog newbornDog = (Dog) dog.givesBirth();

        System.out.println(newbornAnimal.getClass().getSimpleName()); // Animal
        System.out.println(newbornDog.getClass().getSimpleName()); // Dog
	}

}
