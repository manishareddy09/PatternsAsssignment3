package threedemo;

public class Dog extends Animal {
	
	@Override
    public Dog givesBirth() {
        return new Dog();
    }

}
