package threedemo;

public class Animal {
	public Animal givesBirth() {
        return new Animal();
    }
}
