package nineteendemo;

public class MyThread1 implements Runnable{
	
	public void run() {
        // thread logic goes here
		System.out.println("Thread is running");
    }
}
