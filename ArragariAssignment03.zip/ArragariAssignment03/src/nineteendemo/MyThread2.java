package nineteendemo;

public class MyThread2 {
	public void run() {
        // thread logic goes here
		System.out.println("MyThread is running");
    
    }

	public void start() {
		// TODO Auto-generated method stub
		System.out.println("MyThread  is running");
		
	}
}
