package nineteendemo;

public class ThreadExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyThread1 myRunnable = new MyThread1();
        Thread thread = new Thread(myRunnable);
        thread.start();
    }

}
