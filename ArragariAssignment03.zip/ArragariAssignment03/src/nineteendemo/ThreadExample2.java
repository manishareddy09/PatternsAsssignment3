package nineteendemo;

public class ThreadExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyThread2 myThread = new MyThread2();
	        myThread.start();
	    }

}
