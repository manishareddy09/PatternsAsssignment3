package twodemo;

public class CarsDriver {
	

    public static void main(String[] args) {
    	
    	Cars cars = new Cars();
        Honda honda = new Honda();

        cars.soundSystem(); 
        cars.airbags(); 
        cars.cruiseControl(); 
        // cars.laneKeepingAssist(); // Compile-time error: The method laneKeepingAssist() from the type Cars is not visible

        System.out.println();

        honda.soundSystem(); 
        honda.airbags(); 
        honda.cruiseControl();
        // honda.laneKeepingAssist(); // Compile-time error: The method laneKeepingAssist() from the type Honda is not visible
    }
}
