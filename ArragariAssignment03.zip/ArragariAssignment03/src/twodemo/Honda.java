package twodemo;

public class Honda extends Cars {
	
	// Override public method with public or protected visibility
	    public void soundSystem() {
	        System.out.println("Honda has Bose premium audio system");
	    }
	 // Override protected method with public visibility
	    public void airbags() {
	    	System.out.println("Honda car has air bags");
	    }
	 // Override package-private method with another package-private method in the same package
	    void cruiseControl() {
	    	System.out.println("Honda car has cruise control");
	    }
	 // Cannot override a private method
	}

