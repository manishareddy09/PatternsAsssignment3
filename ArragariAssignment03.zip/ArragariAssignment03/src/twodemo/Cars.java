package twodemo;

public class Cars {
	
	    public void soundSystem() {
	        System.out.println("Every Car has sound system");
	    }
	    protected void airbags() {
	    	System.out.println("Every car has air bags");
	    }
	    void cruiseControl(){
	    	System.out.println("Every car has cruise control");
	    }
	    private void laneKeepingAssist(){
	    	System.out.println("Every car has lane keeping assist");
	    }
	}

