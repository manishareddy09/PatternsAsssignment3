package sixteendemo;

import java.util.HashMap;
import java.util.Map;

public class HashMapExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 // Create a new HashMap object
        Map<String, Integer> map = new HashMap<>();

        // Add some key-value pairs to the map
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);

        // Retrieve values using the keys
        int one = map.get("one");
        int two = map.get("two");
        int three = map.get("three");

        System.out.println("Value of 'one': " + one);
        System.out.println("Value of 'two': " + two);
        System.out.println("Value of 'three': " + three);
    }
	}


