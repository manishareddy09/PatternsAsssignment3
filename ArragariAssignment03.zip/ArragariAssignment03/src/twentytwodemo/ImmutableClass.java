package twentytwodemo;

public class ImmutableClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 // Create a String object
        String str1 = "Hello";
        
        // Concatenate the String with another String
        String str2 = str1 + " World";
        
        // Print the original String and the concatenated String
        System.out.println("Original String: " + str1);
        System.out.println("Concatenated String: " + str2);
	}

}
