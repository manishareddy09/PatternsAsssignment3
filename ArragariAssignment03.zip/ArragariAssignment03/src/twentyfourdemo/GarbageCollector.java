package twentyfourdemo;

public class GarbageCollector {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Create some objects
        Object obj1 = new Object();
        Object obj2 = new Object();
        Object obj3 = new Object();
        
        // Nullify the references to the objects
        obj1 = null;
        obj2 = null;
        obj3 = null;
        
        // Call the garbage collector explicitly
        System.gc();
        System.out.println("Garbage Collector");
        }

}
