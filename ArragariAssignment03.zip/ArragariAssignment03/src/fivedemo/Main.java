package fivedemo;

public class Main {
	public static void main(String[] args) {
        // Using StringBuffer
        StringBuffer stringBuffer = new StringBuffer("Hello");
        stringBuffer.append(" ");
        stringBuffer.append("World");
        System.out.println("StringBuffer: " + stringBuffer.toString());

        // Using StringBuilder
        StringBuilder stringBuilder = new StringBuilder("Hello");
        stringBuilder.append(" ");
        stringBuilder.append("World");
        System.out.println("StringBuilder: " + stringBuilder.toString());
    }
}
