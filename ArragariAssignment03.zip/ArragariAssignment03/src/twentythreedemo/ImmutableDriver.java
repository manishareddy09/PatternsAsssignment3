package twentythreedemo;

public class ImmutableDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 // Create an ImmutablePerson object
        ImmutablePerson person = new ImmutablePerson("Sam", 30);
        
        // Modify the object using withName and withAge methods
        ImmutablePerson modifiedPerson1 = person.withName("Honey");
        ImmutablePerson modifiedPerson2 = person.withAge(35);
        
        // Print the original object and the modified objects
        System.out.println("Original: " + person.getName() + ", " + person.getAge());
        System.out.println("Modified 1: " + modifiedPerson1.getName() + ", " + modifiedPerson1.getAge());
        System.out.println("Modified 2: " + modifiedPerson2.getName() + ", " + modifiedPerson2.getAge());
	}

}
