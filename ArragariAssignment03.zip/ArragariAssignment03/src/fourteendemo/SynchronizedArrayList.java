package fourteendemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SynchronizedArrayList {	

	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		List<String> list = Collections.synchronizedList(new ArrayList<String>()); 
		
		list.add("Jung");
		list.add("Kook");
		
		
        // Make ArrayList methods synchronized using synchronized keyword
        synchronized(list) {
        	for (String element : list) {
                System.out.println(element);
            }
        }
    }
}
